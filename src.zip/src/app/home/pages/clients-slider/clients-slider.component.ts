import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clients-slider',
  templateUrl: './clients-slider.component.html',
  styleUrls: ['./clients-slider.component.css']
})
export class ClientsSliderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
