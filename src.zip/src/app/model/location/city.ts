export interface Citiesmodel
{
     id:number,
     cities:string,
}