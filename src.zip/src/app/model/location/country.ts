export interface Countrymodel
{
     id:number,
     country:string,
     currency:string,
     phonecode:any,
}