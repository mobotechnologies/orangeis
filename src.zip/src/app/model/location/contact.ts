
export interface Contactmodel {
  contactName: any,
  contactEmail: any,
  phoneCode: any,
  contactPhone: any,
  country: any,
  state: any,
  comment: any,
}