export interface Statesmodel
{
     id:number,
     states:string,
}