export class Rfqmainform 
{
    constructor(
         public rfqtype:string,
         public rfqmodetype:string,
         public name:string,
         public email:any,
         public reference:any
         
    )
    {}
}