export const environment = {
  production: true,
  url:'https://www.famposo.com/testsoftlaunch/api/'
};
